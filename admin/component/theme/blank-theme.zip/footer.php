<?php if ($mod==""){
	header('location:../../404.php');
}else{
?>
	
    <!-- JavaScript -->
	
</body>
</html>
<?php } ?>