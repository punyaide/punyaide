<?php if ($mod==""){
	header('location:../../404.php');
}else{
?>

<?php } ?>